-- phpMyAdmin SQL Dump
-- version 4.4.14.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 12, 2016 at 05:32 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `botcardz`
--

-- --------------------------------------------------------

--
-- Table structure for table `certificates`
--

DROP TABLE IF EXISTS `certificates`;
CREATE TABLE IF NOT EXISTS `certificates` (
  `token` varchar(6) NOT NULL DEFAULT '',
  `piece` varchar(5) DEFAULT NULL,
  `broker` varchar(4) NOT NULL,
  `player` varchar(6) DEFAULT NULL,
  `datetime` varchar(19) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `players`
--

DROP TABLE IF EXISTS `players`;
CREATE TABLE IF NOT EXISTS `players` (
  `seq` int(11) NOT NULL,
  `agent` varchar(4) NOT NULL,
  `player` varchar(32) NOT NULL,
  `cash` int(11) NOT NULL,
  `round` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pool`
--

DROP TABLE IF EXISTS `pool`;
CREATE TABLE IF NOT EXISTS `pool` (
  `token` varchar(6) NOT NULL DEFAULT '',
  `piece` varchar(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pool`
--

INSERT INTO `pool` (`token`, `piece`) VALUES
('10795', '-2'),
('10a21', '-1'),
('10dc7', '-1'),
('1158', '-1'),
('11c51', '-1'),
('12547', '-1'),
('130a3', '-1'),
('13aa9', '-2'),
('14650', '-1'),
('14a5', '-0'),
('14bf2', '-2'),
('14e45', '-1'),
('152ce', '-2'),
('158b7', '-2'),
('15b72', '-1'),
('164ca', '-0'),
('16a30', '-0'),
('16b4b', '-1'),
('16d48', '-1'),
('17689', '-0'),
('19f3c', '-1'),
('1a1f5', '-0'),
('1b759', '-0'),
('1b99b', '-1'),
('1ccf6', '-2'),
('1cd13', '-2'),
('1cf5c', '-1'),
('1d4cb', '-0'),
('1e0dd', '-2'),
('1eb09', '-2'),
('1f360', '-0'),
('1f567', '-0'),
('204d4', '-0'),
('21b9e', '-1'),
('2256b', '-2'),
('2264a', '-1'),
('2314c', '-1'),
('23319', '-2'),
('23a73', '-0'),
('24f33', '-2'),
('252fd', '-2'),
('254c2', '-2'),
('25555', '-1'),
('2569e', '-0'),
('25eae', '-1'),
('2661a', '-0'),
('26930', '-2'),
('293c2', '-1'),
('298cd', '-2'),
('29af0', '-2'),
('2a48a', '-0'),
('2ad03', '-0'),
('2b30e', '-1'),
('2b514', '-0'),
('2c3ed', '-1'),
('2c758', '-0'),
('2d228', '-0'),
('2d504', '-1'),
('2dd2', '-2'),
('2e349', '-2'),
('2efd9', '-1'),
('2f004', '-2'),
('2f4e7', '-0'),
('300bd', '-2'),
('30101', '-2'),
('3090d', '-2'),
('3105b', '-0'),
('3185c', '-2'),
('31a71', '-1'),
('31a81', '-0'),
('32e21', '-2'),
('33745', '-2'),
('33995', '-1'),
('33b93', '-2'),
('345a9', '-2'),
('34880', '-2'),
('35156', '-0'),
('3555a', '-2'),
('360ab', '-1'),
('36c6', '-2'),
('3769e', '-0'),
('3775b', '-2'),
('38080', '-2'),
('382d4', '-2'),
('384bc', '-1'),
('38e09', '-1'),
('3a062', '-1'),
('3a423', '-1'),
('3a5cc', '-1'),
('3ab3f', '-0'),
('3b76c', '-2'),
('3bb17', '-0'),
('3bc05', '-1'),
('3bf82', '-1'),
('3c140', '-2'),
('3c1da', '-2'),
('3c1de', '-1'),
('3ecb9', '-2'),
('3f1e', '-0'),
('3f294', '-0'),
('4117', '-0'),
('41227', '-1'),
('41a4', '-1'),
('429c7', '-1'),
('42a22', '-2'),
('42b32', '-2'),
('43555', '-1'),
('43f65', '-1'),
('44a16', '-0'),
('45408', '-0'),
('45d30', '-0'),
('46033', '-0'),
('4647c', '-2'),
('46894', '-1'),
('468b7', '-0'),
('46d44', '-1'),
('46d62', '-0'),
('46f55', '-0'),
('47cfd', '-0'),
('4831c', '-1'),
('48337', '-1'),
('4867c', '-2'),
('4929', '-2'),
('49844', '-1'),
('49e13', '-1'),
('49e60', '-1'),
('4a92e', '-2'),
('4ab19', '-2'),
('4c3cb', '-2'),
('4c3f4', '-0'),
('4c61e', '-1'),
('4cb0c', '-0'),
('4cdf7', '-1'),
('4d43b', '-2'),
('4e5bf', '-1'),
('4e5ec', '-2'),
('4fa67', '-0'),
('4fb69', '-2'),
('50541', '-2'),
('505e9', '-2'),
('51175', '-2'),
('515dd', '-2'),
('5161d', '-0'),
('519a8', '-1'),
('525c4', '-2'),
('531d0', '-1'),
('534a', '-2'),
('53974', '-2'),
('55901', '-0'),
('57725', '-2'),
('57bf6', '-1'),
('58653', '-2'),
('58caf', '-2'),
('58d3e', '-0'),
('58dab', '-0'),
('5953c', '-2'),
('59a8e', '-2'),
('59ce0', '-2'),
('59dc8', '-0'),
('5a412', '-2'),
('5acf8', '-0'),
('5b5c5', '-0'),
('5b63b', '-0'),
('5c375', '-1'),
('5c566', '-1'),
('5cd5d', '-1'),
('5cf92', '-1'),
('5d05a', '-1'),
('5dcd0', '-0'),
('5e672', '-2'),
('6047b', '-0'),
('60695', '-0'),
('607f1', '-2'),
('60805', '-1'),
('60ee5', '-1'),
('614d0', '-0'),
('616ef', '-0'),
('6182', '-0'),
('6195d', '-1'),
('61e78', '-1'),
('62273', '-0'),
('635ae', '-1'),
('63da', '-2'),
('64496', '-2'),
('6470a', '-0'),
('64c16', '-2'),
('64ce0', '-1'),
('66284', '-1'),
('664f9', '-2'),
('6798e', '-0'),
('67a1a', '-0'),
('67b7e', '-0'),
('683f3', '-2'),
('686ea', '-0'),
('68db5', '-1'),
('69288', '-0'),
('69ace', '-0'),
('6a081', '-2'),
('6a6d6', '-2'),
('6c1a4', '-1'),
('6c455', '-0'),
('6c991', '-0'),
('6d6f2', '-0'),
('6de21', '-0'),
('6e00d', '-2'),
('6f4b8', '-1'),
('6f4da', '-0'),
('6fd76', '-1'),
('6ffec', '-1'),
('6ffff', '-1'),
('703aa', '-2'),
('7059f', '-2'),
('7196', '-0'),
('71cc0', '-2'),
('72bf0', '-1'),
('7359d', '-2'),
('737b', '-2'),
('73be', '-2'),
('73e5', '-1'),
('74119', '-1'),
('74474', '-1'),
('746c9', '-0'),
('74d34', '-2'),
('7506e', '-1'),
('76108', '-1'),
('762da', '-0'),
('76f9b', '-1'),
('77a9d', '-2'),
('78513', '-2'),
('79017', '-1'),
('7a95c', '-1'),
('7ba6d', '-2'),
('7c371', '-0'),
('7cff9', '-1'),
('7d1bc', '-0'),
('7d4c3', '-0'),
('7d7f5', '-0'),
('7e8be', '-2'),
('7f327', '-0'),
('7ff49', '-2'),
('80074', '-1'),
('8142', '-2'),
('815a6', '-0'),
('829e4', '-2'),
('82e6c', '-1'),
('83090', '-0'),
('83648', '-1'),
('844d7', '-2'),
('84fa2', '-1'),
('85d95', '-0'),
('86003', '-0'),
('868bd', '-2'),
('879a1', '-1'),
('87aa8', '-1'),
('8815f', '-1'),
('88763', '-0'),
('88cd5', '-0'),
('8a7b2', '-0'),
('8af6d', '-1'),
('8b37d', '-0'),
('8ba2', '-0'),
('8ba78', '-0'),
('8bee', '-0'),
('8c28c', '-1'),
('8c83', '-2'),
('8cc80', '-1'),
('8d368', '-0'),
('8d671', '-1'),
('8d7e2', '-1'),
('8db81', '-1'),
('8e9ed', '-2'),
('8ee17', '-0'),
('8f31f', '-2'),
('8fa1b', '-1'),
('90a15', '-0'),
('90acf', '-2'),
('90cfd', '-0'),
('9143c', '-1'),
('91d9b', '-2'),
('91e9', '-2'),
('92352', '-0'),
('92a91', '-1'),
('92be0', '-0'),
('93773', '-0'),
('93af7', '-2'),
('9493d', '-1'),
('94a27', '-2'),
('94c0b', '-2'),
('95079', '-2'),
('965f2', '-1'),
('9663', '-2'),
('969ad', '-2'),
('971a9', '-0'),
('9774a', '-0'),
('97a37', '-1'),
('9898', '-1'),
('98995', '-0'),
('98c66', '-1'),
('99075', '-0'),
('99499', '-2'),
('9a249', '-2'),
('9a4c', '-2'),
('9a671', '-0'),
('9a7b2', '-1'),
('9ab6c', '-2'),
('9ae11', '-2'),
('9afe4', '-1'),
('9b454', '-1'),
('9bf3d', '-1'),
('9bfb7', '-0'),
('9cdae', '-0'),
('9d351', '-1'),
('9d88f', '-1'),
('9e4ec', '-0'),
('9e51c', '-2'),
('9e9b5', '-0'),
('9f4ab', '-1'),
('9f5be', '-0'),
('9f662', '-2'),
('9f6e7', '-0'),
('9f78d', '-0'),
('a09a4', '-1'),
('a15fe', '-2'),
('a1bbe', '-0'),
('a309', '-0'),
('a333c', '-0'),
('a411f', '-2'),
('a4e5d', '-2'),
('a664e', '-2'),
('a73ae', '-0'),
('a7d4a', '-0'),
('a868', '-2'),
('a8704', '-2'),
('a8739', '-0'),
('a8bc3', '-2'),
('a8da9', '-2'),
('a9679', '-0'),
('aa422', '-0'),
('aa4b0', '-2'),
('ab6f4', '-1'),
('ac376', '-2'),
('ac3f9', '-0'),
('ac597', '-2'),
('ac83c', '-1'),
('ad40f', '-0'),
('ad4f5', '-2'),
('ad5f4', '-1'),
('ad91b', '-2'),
('ae1c6', '-2'),
('ae755', '-0'),
('ae870', '-1'),
('ae988', '-1'),
('af1f9', '-1'),
('af503', '-0'),
('af9af', '-0'),
('b035b', '-1'),
('b035d', '-2'),
('b0ad1', '-1'),
('b21ae', '-2'),
('b2dcc', '-1'),
('b2eec', '-0'),
('b30d1', '-1'),
('b5712', '-2'),
('b5992', '-0'),
('b71c7', '-2'),
('b725e', '-1'),
('b7880', '-1'),
('b7fca', '-1'),
('b809', '-1'),
('b879', '-1'),
('b8999', '-1'),
('b89d8', '-0'),
('b8e99', '-0'),
('b92ea', '-0'),
('ba04', '-1'),
('ba16c', '-0'),
('ba57b', '-2'),
('ba7d', '-2'),
('bb2b0', '-0'),
('bba5b', '-1'),
('bbaf4', '-0'),
('bbbbc', '-1'),
('bbd7f', '-2'),
('bbe08', '-0'),
('bbfc3', '-0'),
('bc2dc', '-2'),
('bc395', '-0'),
('bd5de', '-2'),
('bd7e6', '-1'),
('bd9e8', '-2'),
('be2f5', '-1'),
('bea45', '-0'),
('bf05', '-2'),
('bf99b', '-0'),
('c0259', '-2'),
('c04d9', '-0'),
('c1f07', '-1'),
('c2232', '-0'),
('c290d', '-2'),
('c2d2a', '-1'),
('c35d', '-0'),
('c3886', '-0'),
('c50c9', '-2'),
('c5805', '-2'),
('c62a1', '-2'),
('c670d', '-1'),
('c6762', '-0'),
('c6908', '-0'),
('c6946', '-2'),
('c6b59', '-0'),
('c797f', '-2'),
('c7dae', '-0'),
('c87e', '-0'),
('c8f01', '-0'),
('c94e3', '-1'),
('c9b25', '-0'),
('ca38d', '-0'),
('ca6ea', '-2'),
('cabc7', '-2'),
('caebc', '-1'),
('cb2f1', '-2'),
('cb7cc', '-0'),
('cc444', '-1'),
('ccc8c', '-1'),
('ccd0d', '-1'),
('cd0c2', '-2'),
('ce063', '-0'),
('ce94d', '-1'),
('cf947', '-1'),
('d0527', '-0'),
('d0732', '-1'),
('d0748', '-2'),
('d0d66', '-0'),
('d0f93', '-2'),
('d1da', '-2'),
('d2873', '-2'),
('d2ac3', '-1'),
('d35bb', '-2'),
('d3b52', '-0'),
('d4ab7', '-0'),
('d4cfe', '-2'),
('d5290', '-1'),
('d5873', '-0'),
('d63b', '-1'),
('d681b', '-1'),
('d6eb6', '-0'),
('d6f51', '-1'),
('d76b9', '-0'),
('d8685', '-2'),
('daeee', '-2'),
('db32f', '-0'),
('db3fd', '-1'),
('dbbc5', '-0'),
('dc2bf', '-1'),
('dc39', '-2'),
('dc6ca', '-1'),
('dd38f', '-2'),
('dda01', '-2'),
('de557', '-1'),
('de6a6', '-0'),
('de922', '-1'),
('df73', '-1'),
('dfc49', '-2'),
('e0464', '-0'),
('e1060', '-1'),
('e1212', '-0'),
('e1416', '-1'),
('e1fb1', '-2'),
('e3e83', '-0'),
('e41eb', '-0'),
('e4832', '-2'),
('e4b43', '-0'),
('e571c', '-1'),
('e5864', '-1'),
('e5dcc', '-1'),
('e68ca', '-2'),
('e73d4', '-2'),
('e77c7', '-0'),
('e7950', '-1'),
('e7b22', '-1'),
('e7c8b', '-2'),
('e7ca0', '-1'),
('e81bb', '-0'),
('e84b6', '-1'),
('e8a1b', '-0'),
('e8d76', '-2'),
('eb352', '-1'),
('ec15b', '-2'),
('ec8c3', '-2'),
('ed5db', '-1'),
('edaa6', '-1'),
('ee997', '-1'),
('ee999', '-2'),
('eef07', '-0'),
('ef282', '-2'),
('efd86', '-2'),
('effbb', '-2'),
('f196f', '-1'),
('f1bc0', '-0'),
('f1c09', '-1'),
('f1ca4', '-0'),
('f1d03', '-0'),
('f24e4', '-1'),
('f2510', '-0'),
('f2e1a', '-2'),
('f2e59', '-0'),
('f328', '-1'),
('f3980', '-2'),
('f3a66', '-0'),
('f3d8', '-0');

-- --------------------------------------------------------

--
-- Table structure for table `properties`
--

DROP TABLE IF EXISTS `properties`;
CREATE TABLE IF NOT EXISTS `properties` (
  `id` varchar(16) NOT NULL,
  `value` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `properties`
--

INSERT INTO `properties` (`id`, `value`) VALUES
('alarm', '1460475094'),
('next_event', '0'),
('potd', 'tuesday'),
('round', '16'),
('startcash', '5000'),
('state', '3');

-- --------------------------------------------------------

--
-- Table structure for table `series`
--

DROP TABLE IF EXISTS `series`;
CREATE TABLE IF NOT EXISTS `series` (
  `code` int(2) NOT NULL DEFAULT '0',
  `description` varchar(16) DEFAULT NULL,
  `frequency` int(3) DEFAULT NULL,
  `value` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `series`
--

INSERT INTO `series` (`code`, `description`, `frequency`, `value`) VALUES
(11, 'Basic house bots', 100, 20),
(13, 'House butlers', 50, 50),
(26, 'Home companions', 20, 200);

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
CREATE TABLE IF NOT EXISTS `transactions` (
  `id` int(11) NOT NULL,
  `datetime` varchar(19) DEFAULT NULL,
  `broker` varchar(4) NOT NULL,
  `player` varchar(6) DEFAULT NULL,
  `series` int(2) DEFAULT NULL,
  `trans` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `code` varchar(4) NOT NULL,
  `name` varchar(64) NOT NULL,
  `role` varchar(8) NOT NULL,
  `password` varchar(128) NOT NULL,
  `last_round` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `certificates`
--
ALTER TABLE `certificates`
  ADD PRIMARY KEY (`token`);

--
-- Indexes for table `players`
--
ALTER TABLE `players`
  ADD PRIMARY KEY (`seq`);

--
-- Indexes for table `pool`
--
ALTER TABLE `pool`
  ADD PRIMARY KEY (`token`);

--
-- Indexes for table `properties`
--
ALTER TABLE `properties`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `series`
--
ALTER TABLE `series`
  ADD PRIMARY KEY (`code`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`code`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `players`
--
ALTER TABLE `players`
  MODIFY `seq` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
