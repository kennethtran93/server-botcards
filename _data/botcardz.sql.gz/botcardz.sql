-- phpMyAdmin SQL Dump
-- version 4.4.14.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 16, 2016 at 04:05 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Botcardz`
--

-- --------------------------------------------------------

--
-- Table structure for table `certificates`
--

DROP TABLE IF EXISTS `certificates`;
CREATE TABLE IF NOT EXISTS `certificates` (
  `token` varchar(6) NOT NULL DEFAULT '',
  `piece` varchar(5) DEFAULT NULL,
  `broker` varchar(4) NOT NULL,
  `player` varchar(6) DEFAULT NULL,
  `datetime` varchar(19) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `certificates`
--

INSERT INTO `certificates` (`token`, `piece`, `broker`, `player`, `datetime`) VALUES
('10DA3E', '11a-1', '', 'Mickey', '2016.02.01-09:01:52'),
('11F084', '11a-1', '', 'Donald', '2016.02.01-09:01:12'),
('11F0C5', '11b-1', '', 'George', '2016.02.01-09:01:30'),
('12072C', '11c-0', '', 'Henry', '2016.02.01-09:01:26'),
('12268C', '11b-0', '', 'Mickey', '2016.02.01-09:01:56'),
('132956', '11c-0', '', 'George', '2016.02.01-09:01:20'),
('135745', '11a-0', '', 'Donald', '2016.02.01-09:01:08'),
('1359B6', '11a-0', '', 'Mickey', '2016.02.01-09:01:22'),
('139244', '11c-0', '', 'George', '2016.02.01-09:01:24'),
('141117', '11c-2', '', 'Henry', '2016.02.01-09:01:54'),
('14338A', '11c-0', '', 'George', '2016.02.01-09:01:36'),
('150417', '11b-2', '', 'Mickey', '2016.02.01-09:01:46'),
('154281', '11c-0', '', 'Donald', '2016.02.01-09:01:50'),
('17DC94', '11b-1', '', 'George', '2016.02.01-09:01:40'),
('19573B', '11a-2', '', 'Donald', '2016.02.01-09:01:44'),
('1A2EE5', '11c-0', '', 'Donald', '2016.02.01-09:01:10'),
('1AB11B', '11a-2', '', 'Henry', '2016.02.01-09:01:32'),
('1ADF71', '11a-1', '', 'George', '2016.02.01-09:01:14'),
('1BB155', '11b-2', '', 'George', '2016.02.01-09:01:00'),
('1BB8CC', '11b-2', '', 'Henry', '2016.02.01-09:01:34'),
('1BE8FA', '11c-0', '', 'George', '2016.02.01-09:01:06'),
('1C292C', '11b-0', '', 'George', '2016.02.01-09:01:16'),
('1C58FB', '11c-2', '', 'Donald', '2016.02.01-09:01:28'),
('1CA087', '11c-1', '', 'Mickey', '2016.02.01-09:01:48'),
('1D17DE', '11a-0', '', 'George', '2016.02.01-09:01:38'),
('1DE9BB', '11b-2', '', 'Donald', '2016.02.01-09:01:04'),
('1E095A', '11c-2', '', 'Donald', '2016.02.01-09:01:18'),
('1E5222', '11c-2', '', 'Donald', '2016.02.01-09:01:42'),
('1E654C', '11b-2', '', 'Mickey', '2016.02.01-09:01:02');

-- --------------------------------------------------------

--
-- Table structure for table `series`
--

DROP TABLE IF EXISTS `series`;
CREATE TABLE IF NOT EXISTS `series` (
  `series` int(2) NOT NULL DEFAULT '0',
  `description` varchar(16) DEFAULT NULL,
  `frequency` int(3) DEFAULT NULL,
  `value` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `series`
--

INSERT INTO `series` (`series`, `description`, `frequency`, `value`) VALUES
(11, 'Basic house bots', 100, 20),
(13, 'House butlers', 50, 50),
(26, 'Home companions', 20, 200);

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
CREATE TABLE IF NOT EXISTS `transactions` (
  `id` int(11) NOT NULL,
  `datetime` varchar(19) DEFAULT NULL,
  `broker` varchar(4) NOT NULL,
  `player` varchar(6) DEFAULT NULL,
  `series` int(2) DEFAULT NULL,
  `trans` varchar(4) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `datetime`, `broker`, `player`, `series`, `trans`) VALUES
(1, '2016.02.01-09:01:00', '', 'Mickey', 11, 'sell'),
(2, '2016.02.01-09:01:05', '', 'Henry', 0, 'buy'),
(3, '2016.02.01-09:01:10', '', 'Mickey', 0, 'buy'),
(4, '2016.02.01-09:01:15', '', 'Donald', 13, 'sell'),
(5, '2016.02.01-09:01:20', '', 'Donald', 0, 'buy'),
(6, '2016.02.01-09:01:25', '', 'Donald', 0, 'buy'),
(7, '2016.02.01-09:01:30', '', 'Donald', 0, 'buy'),
(8, '2016.02.01-09:01:35', '', 'Donald', 0, 'buy'),
(9, '2016.02.01-09:01:40', '', 'Henry', 0, 'buy'),
(10, '2016.02.01-09:01:45', '', 'Donald', 22, 'sell'),
(11, '2016.02.01-09:01:50', '', 'George', 11, 'sell'),
(12, '2016.02.01-09:01:55', '', 'George', 0, 'buy'),
(13, '2016.02.01-09:01:60', '', 'George', 0, 'buy');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `code` varchar(4) NOT NULL,
  `name` varchar(64) NOT NULL,
  `role` varchar(8) NOT NULL,
  `password` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`code`, `name`, `role`, `password`) VALUES
('jlp', 'James', 'boss', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `certificates`
--
ALTER TABLE `certificates`
  ADD PRIMARY KEY (`token`);

--
-- Indexes for table `series`
--
ALTER TABLE `series`
  ADD PRIMARY KEY (`series`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`code`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
